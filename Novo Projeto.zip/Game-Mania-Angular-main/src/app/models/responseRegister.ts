export class ResponseRegister {
  public jwt: string;
}
